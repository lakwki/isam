﻿namespace com.next.isam.dataserver.model.account.DailySunInterfaceDsTableAdapters
{
}
namespace com.next.isam.dataserver.model.account
{
}
namespace com.next.isam.dataserver.model.account {
    
    
    public partial class DailySunInterfaceDs {
    }
}
namespace com.next.isam.dataserver.model.account {
    
    
    public partial class DailySunInterfaceDs {
    }
}
